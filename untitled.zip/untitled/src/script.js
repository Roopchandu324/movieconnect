// Script to handle login and signup form submissions

document.getElementById('signupForm')?.addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Sign up successful! You can now log in.');
    // Here you would typically send the data to your server
});

document.getElementById('loginForm')?.addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Login successful! Redirecting to homepage...');
    // Here you would typically authenticate the user and redirect them
});
